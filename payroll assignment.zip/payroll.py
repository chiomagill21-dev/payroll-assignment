import random

def generate_payroll():
    try:
        workers = []
        genders = ["Male", "Female"]
        
        # Step 2: Create a list of 400 workers dynamically
        for i in range(1, 401):
            workers.append({
                "id": i,
                "name": f"Worker_{i}",
                "salary": random.randint(5000, 35000),
                "gender": random.choice(genders)
            })

        # Step 3 & 4: Loop and Conditional logic
        print(f"{'ID':<5} | {'Salary':<10} | {'Gender':<8} | {'Level'}")
        print("-" * 40)
        
        for worker in workers:
            salary = worker["salary"]
            gender = worker["gender"]
            level = "Standard"

            # Specific conditions
            if 10000 < salary < 20000:
                level = "A1"
            
            # The A5-F level overrides or adds logic based on female gender
            if 7500 < salary < 30000 and gender == "Female":
                level = "A5-F"

            print(f"{worker['id']:<5} | ${salary:<9} | {gender:<8} | {level}")

    except Exception as e:
        print(f"An error occurred during payroll generation: {e}")

if __name__ == "__main__":
    generate_payroll()