# Step 6: Convert Python code into R
generate_payroll <- function() {
  tryCatch({
    # Step 2: Create dynamic data
    set.seed(123) 
    # For reproducibility
    num_workers <- 400
    
    workers <- data.frame(
      id = 1:num_workers,
      name = paste0("Worker_", 1:num_workers),
      salary = sample(5000:35000, num_workers, replace = TRUE),
      gender = sample(c("Male", "Female"), num_workers, replace = TRUE),
      stringsAsFactors = FALSE
    )
    
    # Step 3 & 4: Initialize level and apply conditions
    workers$level <- "Standard"
    
    # Using vectorized operations (R's version of a loop/conditional)
    # Condition 1: A1
    workers$level[workers$salary > 10000 & workers$salary < 20000] <- "A1"
    
    # Condition 2: A5-F
    workers$level[workers$salary > 7500 & workers$salary < 30000 & workers$gender == "Female"] <- "A5-F"
    
    # Print results
    print(head(workers, 20)) # Displaying first 20 for brevity
    
  }, error = function(e) {
    message("An error occurred: ", e$message)
  })
}

generate_payroll()