> Worker Payment System
> 
> 
> Description
> 
> 
> This project contains two scripts (Python and R) designed to dynamically generate a payroll list of 400 workers and assign employee levels based on salary and gender criteria.
> How to Run
> 
> 
> 1.Python:
> * Ensure you have Python 3.x installed.
> * Run `python payroll.py` in your terminal.
> 
> 
> 2.R:
> * Ensure you have R installed.
> * Run the script using `Rscript payroll.R` or via RStudio.
> 
> Logic Criteria
> 
> 
> * Level A1**: Salary between $10,000 and $20,000.
> * Level A5-F: Female employees with salary between $7,500 and $30,000.
